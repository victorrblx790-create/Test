package br.com.protocolozero

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.launch
import br.com.protocolozero.data.ZeroDatabase
import br.com.protocolozero.data.InventoryRecord
import br.com.protocolozero.data.ChecklistRecord

private val Bg = Color(0xFF090D0B)
private val Panel = Color(0xFF151D19)
private val Green = Color(0xFF65D98A)
private val Muted = Color(0xFF9AA9A0)
private val Amber = Color(0xFFFFC857)
private val Red = Color(0xFFFF6262)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(9, 13, 11)
        window.navigationBarColor = android.graphics.Color.rgb(9, 13, 11)
        setContent { ZeroApp() }
    }
}

@Composable
fun ZeroApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("zero_local", Context.MODE_PRIVATE) }
    val database = remember { ZeroDatabase.get(context) }
    val dao = remember { database.dao() }
    val scope = rememberCoroutineScope()
    var page by remember { mutableStateOf("INÍCIO") }
    var inventory by remember { mutableStateOf(loadList(prefs, "inventory")) }
    var tasks by remember { mutableStateOf(loadList(prefs, "tasks", listOf("Separar água potável", "Conferir alimentos", "Verificar lanternas", "Revisar contatos familiares", "Conferir kit de primeiros socorros"))) }
    var databaseReady by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val storedInventory = dao.getInventory()
        val storedTasks = dao.getChecklist()
        if (storedInventory.isEmpty()) {
            val legacy = loadList(prefs, "inventory")
            if (legacy.isNotEmpty()) dao.replaceInventory(legacy.map { InventoryRecord(description = it) })
        }
        if (storedTasks.isEmpty()) {
            val legacy = loadList(prefs, "tasks", listOf("Separar água potável", "Conferir alimentos", "Verificar lanternas", "Revisar contatos familiares", "Conferir kit de primeiros socorros"))
            dao.replaceChecklist(legacy.mapIndexed { index, value ->
                ChecklistRecord(description = value.removePrefix("✓ "), completed = value.startsWith("✓ "), position = index)
            })
        }
        inventory = dao.getInventory().map { it.description }
        tasks = dao.getChecklist().map { if (it.completed) "✓ ${it.description}" else it.description }
        databaseReady = true
    }
    var people by remember { mutableStateOf(prefs.getInt("people", 1).toString()) }
    var liters by remember { mutableStateOf(prefs.getString("liters", "0") ?: "0") }
    var days by remember { mutableStateOf("3") }
    var daily by remember { mutableStateOf("2") }
    var gameScore by remember { mutableIntStateOf(prefs.getInt("best2048", 0)) }
    var game by remember { mutableStateOf(loadIntList(prefs, "gameBoard", listOf(2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2))) }
    var familyContacts by remember { mutableStateOf(loadList(prefs, "familyContacts")) }
    var videoUri by remember { mutableStateOf(prefs.getString("lastVideo", null)) }
    var status by remember { mutableStateOf("SISTEMA LOCAL • DADOS NESTE DISPOSITIVO") }

    fun saveList(key: String, values: List<String>) {
        prefs.edit().putString(key, JSONArray(values).toString()).apply()
        if (databaseReady) scope.launch {
            if (key == "inventory") dao.replaceInventory(values.map { InventoryRecord(description = it) })
            if (key == "tasks") dao.replaceChecklist(values.mapIndexed { index, value ->
                ChecklistRecord(
                    description = value.removePrefix("✓ "),
                    completed = value.startsWith("✓ "),
                    position = index
                )
            })
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Green, secondary = Amber, background = Bg,
            surface = Panel, onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Green) {
                    listOf("INÍCIO", "ESTOQUE", "PLANO", "FERRAMENTAS").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        "INÍCIO" -> Icons.Default.Dashboard
                                        "ESTOQUE" -> Icons.Default.Inventory2
                                        "PLANO" -> Icons.Default.Checklist
                                        else -> Icons.Default.Build
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item, fontSize = 9.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Header(if (databaseReady) "$status • BANCO LOCAL OK" else "$status • INICIALIZANDO BANCO")
                when (page) {
                    "INÍCIO" -> Dashboard(
                        inventory.size, tasks.count { it.startsWith("✓ ") }, tasks.size,
                        onNavigate = { page = it }
                    )
                    "ESTOQUE" -> InventoryScreen(inventory, onAdd = {
                        inventory = inventory + it
                        saveList("inventory", inventory)
                    }, onRemove = {
                        inventory = inventory - it
                        saveList("inventory", inventory)
                    })
                    "PLANO" -> ChecklistScreen(tasks, onChange = {
                        tasks = it
                        saveList("tasks", tasks)
                    })
                    else -> ToolsScreen(
                        context, prefs, people, { people = it; prefs.edit().putInt("people", it.toIntOrNull() ?: 1).apply() },
                        liters, { liters = it; prefs.edit().putString("liters", it).apply() },
                        days, { days = it }, daily, { daily = it },
                        game, { game = it; prefs.edit().putString("gameBoard", JSONArray(it).toString()).apply() }, gameScore, { gameScore = it; prefs.edit().putInt("best2048", it).apply() },
                        videoUri, { videoUri = it; prefs.edit().putString("lastVideo", it).apply() },
                        familyContacts, { familyContacts = it; prefs.edit().putString("familyContacts", JSONArray(it).toString()).apply() },
                        onStatus = { status = it },
                        initialSection = when (page) {
                            "CALCULADORAS" -> "CALCULADORAS"
                            "MANUAIS" -> "MANUAIS"
                            "JOGOS" -> "JOGOS"
                            "VÍDEOS", "CINEMA OFFLINE" -> "CINEMA OFFLINE"
                            "SOS", "LANTERNA SOS" -> "LANTERNA SOS"
                            "PLUTO TV" -> "PLUTO TV"
                            "BÚSSOLA" -> "BÚSSOLA"
                            "MONITOR" -> "MONITOR"
                            "SOBREVIVÊNCIA" -> "SOBREVIVÊNCIA"
                            "CENTRAL MULTIMÍDIA" -> "CENTRAL MULTIMÍDIA"
                            else -> "EMERGÊNCIA"
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun Header(status: String) {
    Column(Modifier.fillMaxWidth().background(Bg).padding(horizontal = 18.dp, vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Green, shape = RoundedCornerShape(7.dp), modifier = Modifier.size(10.dp)) {}
            Spacer(Modifier.width(9.dp))
            Text("PROTOCOLO ZERO", color = Color.White, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Spacer(Modifier.weight(1f))
            Text("v0.3", color = Muted, fontSize = 11.sp)
        }
        Spacer(Modifier.height(5.dp))
        Text(status, color = Green, fontSize = 9.sp, letterSpacing = 1.sp)
    }
}

@Composable
fun Dashboard(stock: Int, completed: Int, total: Int, onNavigate: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Spacer(Modifier.height(4.dp))
            Text("CENTRAL DE COMANDO", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
            Text("Esteja preparado.", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("ESTOQUE", stock.toString(), "itens cadastrados", Green, Modifier.weight(1f))
                MetricCard("PLANO", "$completed/$total", "tarefas concluídas", Amber, Modifier.weight(1f))
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, null, tint = Green)
                        Spacer(Modifier.width(8.dp))
                        Text("STATUS DO SISTEMA", fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Modo local disponível", color = Green, fontWeight = FontWeight.SemiBold)
                    Text("Inventário, plano, calculadoras, manuais e mídia local podem ser usados sem internet. GPS e sensores dependem do hardware.", color = Muted, fontSize = 12.sp)
                }
            }
        }
        item { Text("ACESSO RÁPIDO", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp) }
        item {
            val shortcuts = listOf(
                Triple("LANTERNA SOS", "Sinalização e contatos", "LANTERNA SOS"),
                Triple("PRIMEIROS SOCORROS", "Protocolos de emergência offline", "PRIMEIROS SOCORROS"),
                Triple("CALCULADORAS", "Água, comida e energia", "CALCULADORAS"),
                Triple("MANUAIS", "Guias essenciais offline", "MANUAIS"),
                Triple("JOGOS", "Entretenimento local", "JOGOS"),
                Triple("CINEMA OFFLINE", "Biblioteca local de vídeos", "CINEMA OFFLINE"),
                Triple("PLUTO TV", "Acesso ao serviço oficial", "PLUTO TV"),
                Triple("BÚSSOLA", "Direção por sensores", "BÚSSOLA"),
                Triple("MONITOR", "Bateria, memória e espaço", "MONITOR"),
                Triple("SOBREVIVÊNCIA", "Guias locais de emergência", "SOBREVIVÊNCIA"),
                Triple("SOBRE", "Limitações e privacidade", "SOBRE")
            )
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                shortcuts.chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        pair.forEach { (title, subtitle, dest) ->
                            Card(
                                modifier = Modifier.weight(1f).clickable { onNavigate(dest) },
                                colors = CardDefaults.cardColors(containerColor = Panel),
                                shape = RoundedCornerShape(13.dp)
                            ) {
                                Column(Modifier.padding(13.dp)) {
                                    Text(title, color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Spacer(Modifier.height(5.dp))
                                    Text(subtitle, color = Muted, fontSize = 10.sp)
                                }
                            }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        item { Text("DICA: cadastre primeiro sua água, alimentos, baterias e contatos essenciais.", color = Muted, fontSize = 11.sp) }
        item { Spacer(Modifier.height(12.dp)) }
    }
}

@Composable
fun MetricCard(title: String, value: String, detail: String, color: Color, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
            Text(value, color = color, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text(detail, color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
fun InventoryScreen(items: List<String>, onAdd: (String) -> Unit, onRemove: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("1") }
    var category by remember { mutableStateOf("Água") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("INVENTÁRIO", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("Cadastre e acompanhe seus suprimentos.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(name, { name = it }, label = { Text("Nome do item") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(7.dp))
        OutlinedTextField(amount, { amount = it }, label = { Text("Quantidade / unidade") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(7.dp))
        var expanded by remember { mutableStateOf(false) }
        Box {
            OutlinedButton(onClick = { expanded = true }) { Text("Categoria: $category") }
            DropdownMenu(expanded, { expanded = false }) {
                listOf("Água", "Alimentos", "Saúde", "Energia", "Ferramentas", "Comunicação", "Outros").forEach {
                    DropdownMenuItem(text = { Text(it) }, onClick = { category = it; expanded = false })
                }
            }
        }
        Button(onClick = {
            if (name.isNotBlank()) {
                onAdd("$category • ${name.trim()} • $amount")
                name = ""; amount = "1"
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("ADICIONAR AO ESTOQUE") }
        Spacer(Modifier.height(12.dp))
        Text("${items.size} ITENS CADASTRADOS", color = Green, fontSize = 11.sp)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            items(items) { item ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(item, Modifier.weight(1f), fontSize = 12.sp)
                        IconButton(onClick = { onRemove(item) }) { Icon(Icons.Default.Delete, "Remover", tint = Red) }
                    }
                }
            }
        }
    }
}

@Composable
fun ChecklistScreen(tasks: List<String>, onChange: (List<String>) -> Unit) {
    var custom by remember { mutableStateOf("") }
    val done = tasks.count { it.startsWith("✓ ") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("PLANO DE PREPARAÇÃO", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("$done de ${tasks.size} concluídas", color = Green, fontSize = 12.sp)
        LinearProgressIndicator(progress = { if (tasks.isEmpty()) 0f else done.toFloat() / tasks.size }, modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp))
        Row {
            OutlinedTextField(custom, { custom = it }, label = { Text("Nova tarefa") }, modifier = Modifier.weight(1f), singleLine = true)
            IconButton(onClick = { if (custom.isNotBlank()) { onChange(tasks + custom.trim()); custom = "" } }) { Icon(Icons.Default.Add, "Adicionar", tint = Green) }
        }
        LazyColumn {
            items(tasks) { task ->
                val checked = task.startsWith("✓ ")
                Row(Modifier.fillMaxWidth().clickable {
                    onChange(tasks.map { if (it == task) { if (checked) it.removePrefix("✓ ") else "✓ $it" } else it })
                }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked, onCheckedChange = {
                        onChange(tasks.map { if (it == task) { if (it.startsWith("✓ ")) it.removePrefix("✓ ") else "✓ $it" } else it })
                    })
                    Text(task.removePrefix("✓ "), color = if (checked) Muted else Color.White, fontSize = 13.sp)
                }
                Divider(color = Panel)
            }
        }
    }
}

@Composable
fun ToolsScreen(
    context: Context, prefs: android.content.SharedPreferences,
    people: String, setPeople: (String) -> Unit, liters: String, setLiters: (String) -> Unit,
    days: String, setDays: (String) -> Unit, daily: String, setDaily: (String) -> Unit,
    game: List<Int>, setGame: (List<Int>) -> Unit, best: Int, setBest: (Int) -> Unit,
    videoUri: String?, setVideoUri: (String?) -> Unit,
    familyContacts: List<String>, setFamilyContacts: (List<String>) -> Unit,
    onStatus: (String) -> Unit,
    initialSection: String = "EMERGÊNCIA"
) {
    var section by remember { mutableStateOf(initialSection) }
    var waterStock by remember { mutableStateOf("20") }
    var watts by remember { mutableStateOf("10") }
    var hours by remember { mutableStateOf("5") }
    var flashlight by remember { mutableStateOf(false) }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            setVideoUri(uri.toString())
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        }
    }
    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            try {
                val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = manager.cameraIdList.firstOrNull {
                    manager.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                }
                if (id == null) onStatus("HARDWARE • FLASH NÃO DISPONÍVEL")
                else {
                    flashlight = !flashlight
                    manager.setTorchMode(id, flashlight)
                    onStatus(if (flashlight) "EMERGÊNCIA • LANTERNA LIGADA" else "SISTEMA LOCAL • LANTERNA DESLIGADA")
                }
            } catch (_: Exception) { onStatus("NÃO FOI POSSÍVEL ACIONAR O FLASH") }
        } else onStatus("PERMISSÃO DE CÂMERA NEGADA • FLASH INDISPONÍVEL")
    }
    val tabs = listOf("EMERGÊNCIA", "LANTERNA SOS", "PRIMEIROS SOCORROS", "CALCULADORAS", "MANUAIS", "JOGOS", "CINEMA OFFLINE", "PLUTO TV", "BÚSSOLA", "MONITOR", "SOBREVIVÊNCIA", "CENTRAL MULTIMÍDIA", "SOBRE")
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Text("FERRAMENTAS", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(tabs) { tab ->
                FilterChip(selected = section == tab, onClick = { section = tab }, label = { Text(tab, fontSize = 10.sp) })
            }
        }
        Spacer(Modifier.height(10.dp))
        when (section) {
            "LANTERNA SOS" -> Box(Modifier.weight(1f)) { SosExtremeScreen() }
            "PRIMEIROS SOCORROS" -> Box(Modifier.weight(1f)) { FirstAidScreen() }
            "CINEMA OFFLINE" -> Box(Modifier.weight(1f)) { CinemaOfflineScreen() }
            "PLUTO TV" -> Box(Modifier.weight(1f)) { PlutoTvScreen() }
            "BÚSSOLA" -> Box(Modifier.weight(1f)) { DigitalCompassScreen() }
            "MONITOR" -> Box(Modifier.weight(1f)) { DeviceMonitorScreen() }
            "SOBREVIVÊNCIA" -> Box(Modifier.weight(1f)) { OfflineSurvivalLibraryScreen() }
            "CENTRAL MULTIMÍDIA" -> Box(Modifier.weight(1f)) {
                MediaHubScreen(onCinema = { section = "CINEMA OFFLINE" }, onPluto = { section = "PLUTO TV" })
            }
            "EMERGÊNCIA" -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.padding(14.dp)) {
                            Text("ILUMINAÇÃO DE EMERGÊNCIA", color = Green, fontWeight = FontWeight.Bold)
                            Text("O flash depende de câmera com LED e permissão do Android.", color = Muted, fontSize = 11.sp)
                            Button(onClick = {
                                if (context.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                                    cameraPermission.launch(Manifest.permission.CAMERA)
                                } else {
                                    try {
                                        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                                        val id = manager.cameraIdList.firstOrNull {
                                            manager.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                                        }
                                        if (id == null) onStatus("HARDWARE • FLASH NÃO DISPONÍVEL")
                                        else {
                                            flashlight = !flashlight
                                            manager.setTorchMode(id, flashlight)
                                            onStatus(if (flashlight) "EMERGÊNCIA • LANTERNA LIGADA" else "SISTEMA LOCAL • LANTERNA DESLIGADA")
                                        }
                                    } catch (_: Exception) { onStatus("NÃO FOI POSSÍVEL ACIONAR O FLASH") }
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text(if (flashlight) "DESLIGAR LANTERNA" else "LIGAR LANTERNA") }
                        }
                    }
                }
                item {
                    var contactName by remember { mutableStateOf("") }
                    var contactNumber by remember { mutableStateOf("") }
                    Text("CONTATOS DA FAMÍLIA", color = Amber, fontWeight = FontWeight.Bold)
                    Text("Cadastre pessoas de confiança. Os números ficam salvos somente neste aparelho.", color = Muted, fontSize = 10.sp)
                    OutlinedTextField(contactName, { contactName = it }, label = { Text("Nome") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(contactNumber, { contactNumber = it }, label = { Text("Telefone") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
                    Button(onClick = {
                        if (contactName.isNotBlank() && contactNumber.isNotBlank()) {
                            setFamilyContacts(familyContacts + "${contactName.trim()} • ${contactNumber.trim()}")
                            contactName = ""; contactNumber = ""
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("SALVAR CONTATO") }
                    familyContacts.forEach { entry ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 3.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                            Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(entry, Modifier.weight(1f), fontSize = 12.sp)
                                IconButton(onClick = {
                                    val number = entry.substringAfter("•", "").trim()
                                    try { context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))) }
                                    catch (_: Exception) { onStatus("NÃO FOI POSSÍVEL ABRIR O DISCADOR") }
                                }) { Icon(Icons.Default.Call, "Ligar", tint = Green) }
                                IconButton(onClick = { setFamilyContacts(familyContacts - entry) }) { Icon(Icons.Default.Delete, "Excluir", tint = Red) }
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("CONTATOS DE EMERGÊNCIA • BRASIL", color = Amber, fontWeight = FontWeight.Bold)
                    listOf("190" to "Polícia Militar", "192" to "SAMU", "193" to "Bombeiros", "199" to "Defesa Civil").forEach { (number, label) ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable {
                            context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
                        }, colors = CardDefaults.cardColors(containerColor = Panel)) {
                            Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(number, color = Green, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.width(14.dp)); Text(label, color = Color.White)
                                Spacer(Modifier.weight(1f)); Icon(Icons.Default.Call, null, tint = Muted)
                            }
                        }
                    }
                    Text("A chamada depende de cobertura e da disponibilidade da rede telefônica.", color = Muted, fontSize = 10.sp)
                }
            }
            "CALCULADORAS" -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Text("AUTONOMIA DE ÁGUA", color = Green, fontWeight = FontWeight.Bold)
                    NumberField("Pessoas", people, setPeople)
                    NumberField("Litros disponíveis", liters, setLiters)
                    NumberField("Consumo por pessoa/dia (L)", daily, setDaily)
                    val p = people.toDoubleOrNull() ?: 0.0
                    val l = liters.toDoubleOrNull() ?: 0.0
                    val d = daily.toDoubleOrNull() ?: 0.0
                    val autonomy = if (p * d > 0) l / (p * d) else 0.0
                    ResultCard("Autonomia estimada", "%.1f dias".format(autonomy), "Necessidade para 3 dias: %.1f L".format(p * d * 3))
                }
                item {
                    Divider(color = Panel)
                    Text("AUTONOMIA DE ENERGIA", color = Green, fontWeight = FontWeight.Bold)
                    NumberField("Energia útil (Wh)", waterStock, { waterStock = it })
                    NumberField("Consumo (W)", watts, { watts = it })
                    NumberField("Horas de uso por dia", hours, { hours = it })
                    val wh = waterStock.toDoubleOrNull() ?: 0.0
                    val w = watts.toDoubleOrNull() ?: 0.0
                    val h = hours.toDoubleOrNull() ?: 0.0
                    ResultCard("Autonomia estimada", if (w > 0) "%.1f horas".format(wh / w) else "—", "Consumo diário: %.1f Wh".format(w * h))
                }
            }
            "MANUAIS" -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Text("BIBLIOTECA ESSENCIAL OFFLINE", color = Green, fontWeight = FontWeight.Bold) }
                val manuals = listOf(
                    "PRIMEIRAS AÇÕES — APAGÃO" to "Confirme se a falta de energia é apenas no imóvel ou também na região, sem se expor. Verifique avisos oficiais por rádio quando disponível. Desligue aparelhos sensíveis e, se for seguro, retire equipamentos da tomada. Deixe uma luz ligada para perceber o retorno da energia. Não toque em fios caídos, postes ou áreas alagadas próximas à rede elétrica.",
                    "ÁGUA SEGURA" to "Use primeiro água armazenada em recipientes próprios, fechados e identificados. Evite água com cheiro, cor ou origem desconhecida. Fervura pode inativar muitos microrganismos, mas não remove combustíveis, metais, agrotóxicos ou outros contaminantes químicos. Se houver suspeita de contaminação química, não tente resolver apenas fervendo: procure outra fonte e siga a orientação da Defesa Civil/autoridade sanitária. Mantenha recipientes limpos e tampados.",
                    "ENERGIA E ILUMINAÇÃO" to "Priorize iluminação LED e lanternas; conserve baterias e power banks para comunicação e necessidades essenciais. Não deixe velas perto de cortinas, camas, crianças ou animais e nunca durma com chama acesa. Não improvise ligações na rede elétrica nem tente alimentar a casa por tomadas. Geradores e motores a combustão devem ficar ao ar livre, longe de portas, janelas e entradas de ar; nunca em casa, garagem ou ambiente fechado, por risco fatal de monóxido de carbono.",
                    "ALIMENTOS E GELADEIRA" to "Mantenha portas da geladeira e do freezer fechadas o máximo possível. Consuma primeiro alimentos que não exigem refrigeração. Não prove alimentos para decidir se estão seguros. Descarte perecíveis que ficaram aquecidos por tempo desconhecido ou que apresentem sinais de deterioração. Mantenha alimentos protegidos de insetos, animais e água de enchente.",
                    "COMUNICAÇÃO SEM INTERNET" to "Tenha uma lista impressa de telefones, endereços, contatos de emergência e pontos de encontro. Combine horários para tentar contato e um familiar de referência fora da região. Mensagens de texto podem consumir menos bateria e, às vezes, completar mesmo quando chamadas falham. Use rádio portátil a pilhas quando houver transmissão local. Economize bateria reduzindo brilho, fechando apps e ativando modo avião quando não precisar de sinal; lembre-se de que modo avião também desliga a rede móvel.",
                    "HIGIENE E SANEAMENTO" to "Lave as mãos com água e sabão quando disponíveis; use álcool 70% quando as mãos não estiverem visivelmente sujas e não houver água. Separe água potável de água de limpeza. Armazene lixo em sacos fechados, mantenha alimentos protegidos e evite contato com água de enchente, que pode conter esgoto, produtos químicos e animais perigosos.",
                    "PRIMEIROS SOCORROS" to "Em emergência grave, acione ajuda: SAMU 192, Bombeiros 193 ou Polícia 190, conforme a situação e a disponibilidade da rede. Em sangramento intenso, aplique pressão direta firme e contínua com pano ou gaze limpa e peça ajuda. Não mova pessoa com suspeita de lesão na coluna, exceto se permanecer no local representar perigo imediato. Não ofereça comida, bebida ou medicamentos a pessoa inconsciente.",
                    "PLANO FAMILIAR E EVACUAÇÃO" to "Defina dois pontos de encontro: um próximo e outro fora do bairro. Escolha um contato de referência fora da região e deixe cópias em papel de documentos, telefones, endereços e informações médicas essenciais. Combine como reunir crianças, idosos, pessoas com deficiência e animais. Em evacuação, siga rotas e orientações oficiais; não atravesse ruas alagadas nem tente passar por áreas com correnteza.",
                    "KIT DE EMERGÊNCIA" to "Organize água, alimentos não perecíveis, medicamentos de uso contínuo, kit de primeiros socorros, lanterna, pilhas, power bank carregado, rádio portátil, carregadores, higiene, roupas, cópias de documentos, dinheiro em espécie e contatos impressos. Revise validade, pilhas, baterias e necessidades específicas de bebês, idosos, pessoas com deficiência e animais.",
                    "TEMPESTADE SOLAR E APAGÃO AMPLO" to "Tempestades geomagnéticas intensas podem afetar alguns sistemas elétricos, satélites, navegação e comunicações de rádio. Isso não significa que um apagão mundial seja iminente ou certo. Este aplicativo não prevê eventos solares e não recebe alertas quando está offline. Em uma crise, confirme informações por mais de uma fonte confiável e siga Defesa Civil, concessionárias e autoridades locais."
                )
                items(manuals) { (title, body) ->
                    var open by remember { mutableStateOf(false) }
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth().clickable { open = !open }) {
                        Column(Modifier.padding(13.dp)) {
                            Text(title, color = Green, fontWeight = FontWeight.Bold)
                            if (open) { Spacer(Modifier.height(7.dp)); Text(body, color = Color.White, fontSize = 12.sp) }
                            else Text("Toque para ler", color = Muted, fontSize = 10.sp)
                        }
                    }
                }
                item { Text("Conteúdo educativo inicial. Consulte autoridades e profissionais para procedimentos específicos.", color = Muted, fontSize = 10.sp) }
            }
            "JOGOS" -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item { GamesLibraryScreen(context = context, onStatus = onStatus) }
                item {
                    Text("JOGO LOCAL • 2048", color = Green, fontWeight = FontWeight.Bold)
                    Text("Toque em um bloco para combinar com um bloco adjacente igual. Versão inicial simplificada por toque.", color = Muted, fontSize = 10.sp)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        game.chunked(4).forEachIndexed { rowIndex, row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                row.forEachIndexed { colIndex, value ->
                                    val idx = rowIndex * 4 + colIndex
                                    Surface(
                                        modifier = Modifier.weight(1f).height(64.dp).clickable {
                                            val next = game.toMutableList()
                                            val neighbor = if (idx % 4 < 3) idx + 1 else idx - 1
                                            if (next[idx] != 0 && next[idx] == next[neighbor]) {
                                                next[idx] *= 2; next[neighbor] = 0
                                                val empty = next.indices.filter { next[it] == 0 }.firstOrNull()
                                                if (empty != null) next[empty] = 2
                                                val score = next.sum()
                                                if (score > best) setBest(score)
                                                setGame(next)
                                            } else if (next[idx] == 0) { next[idx] = 2; setGame(next) }
                                        },
                                        color = if (value == 0) Panel else Color(0xFF294936),
                                        shape = RoundedCornerShape(8.dp)
                                    ) { Box(contentAlignment = Alignment.Center) { Text(if (value == 0) "" else value.toString(), color = Color.White, fontWeight = FontWeight.Bold) } }
                                }
                            }
                        }
                    }
                    Text("Pontuação acumulada: ${game.sum()} • Melhor: $best", color = Muted, fontSize = 11.sp)
                    OutlinedButton(onClick = { setGame(List(16) { if (it == 0 || it == 15) 2 else 0 }) }) { Text("REINICIAR") }
                }
                item { Text("O 2048 é executado dentro do PROTOCOLO ZERO. Os três jogos listados acima são aplicativos externos e só podem ser abertos quando instalados no Android.", color = Muted, fontSize = 11.sp) }
            }
            "VÍDEOS" -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Text("BIBLIOTECA DE VÍDEOS LOCAIS", color = Green, fontWeight = FontWeight.Bold)
                    Text("Selecione um vídeo armazenado no dispositivo. A reprodução usa o player instalado no Android.", color = Muted, fontSize = 11.sp)
                    Button(onClick = { videoPicker.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth()) { Text("ADICIONAR VÍDEO DO DISPOSITIVO") }
                }
                item {
                    if (videoUri != null) {
                        Text("Último arquivo selecionado", color = Amber)
                        Text(videoUri!!, color = Muted, fontSize = 9.sp)
                        Button(onClick = {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW).apply {
                                    setDataAndType(Uri.parse(videoUri), "video/*")
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(intent)
                            } catch (_: Exception) { onStatus("NÃO FOI POSSÍVEL ABRIR O VÍDEO") }
                        }, modifier = Modifier.fillMaxWidth()) { Text("REPRODUZIR VÍDEO") }
                    } else Text("Nenhum vídeo selecionado.", color = Muted)
                }
                item { Text("Links do YouTube são links online; esta versão não baixa nem converte vídeos. Use downloads oficiais quando disponíveis ou importe arquivos que você tem direito de armazenar.", color = Muted, fontSize = 11.sp) }
            }
            else -> {
                val backupDao = remember { ZeroDatabase.get(context).dao() }
                val backupScope = rememberCoroutineScope()
                val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
                    if (uri != null) {
                        try {
                            val snapshot = JSONObject()
                            listOf("inventory", "tasks", "familyContacts", "gameBoard", "lastVideo", "people", "liters", "best2048").forEach { key ->
                                val value = prefs.getAll()[key]
                                when (value) {
                                    is String -> snapshot.put(key, value)
                                    is Int -> snapshot.put(key, value)
                                    is Boolean -> snapshot.put(key, value)
                                    null -> Unit
                                    else -> snapshot.put(key, value.toString())
                                }
                            }
                            context.contentResolver.openOutputStream(uri)?.use { it.write(snapshot.toString(2).toByteArray(Charsets.UTF_8)) }
                            onStatus("BACKUP EXPORTADO")
                        } catch (_: Exception) { onStatus("ERRO AO EXPORTAR BACKUP") }
                    }
                }
                val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                    if (uri != null) {
                        try {
                            val json = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                                ?: throw IllegalStateException("Arquivo vazio")
                            val snapshot = JSONObject(json)
                            val editor = prefs.edit()
                            listOf("inventory", "tasks", "familyContacts", "gameBoard", "lastVideo", "people", "liters", "best2048").forEach { key ->
                                if (snapshot.has(key) && !snapshot.isNull(key)) {
                                    when (val value = snapshot.get(key)) {
                                        is String -> editor.putString(key, value)
                                        is Int -> editor.putInt(key, value)
                                        is Boolean -> editor.putBoolean(key, value)
                                        else -> editor.putString(key, value.toString())
                                    }
                                }
                            }
                            editor.apply()
                            backupScope.launch {
                                try {
                                    if (snapshot.has("inventory")) {
                                        val raw = snapshot.optString("inventory", "[]")
                                        val arr = JSONArray(raw)
                                        backupDao.replaceInventory((0 until arr.length()).map { InventoryRecord(description = arr.getString(it)) })
                                    }
                                    if (snapshot.has("tasks")) {
                                        val raw = snapshot.optString("tasks", "[]")
                                        val arr = JSONArray(raw)
                                        backupDao.replaceChecklist((0 until arr.length()).map { index ->
                                            val value = arr.getString(index)
                                            ChecklistRecord(description = value.removePrefix("✓ "), completed = value.startsWith("✓ "), position = index)
                                        })
                                    }
                                    onStatus("BACKUP IMPORTADO • REABRA O APP PARA ATUALIZAR AS TELAS")
                                } catch (_: Exception) { onStatus("BACKUP LIDO, MAS NÃO FOI POSSÍVEL RESTAURAR AS LISTAS") }
                            }
                        } catch (_: Exception) { onStatus("BACKUP INVÁLIDO OU NÃO COMPATÍVEL") }
                    }
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        Text("PROTOCOLO ZERO • VERSÃO 0.3", color = Green, fontWeight = FontWeight.Bold)
                        Text("Dados locais, sem conta obrigatória. O backup reúne listas, contatos, progresso do jogo e preferências básicas em um arquivo JSON.", color = Muted, fontSize = 12.sp)
                        Button(onClick = { backupLauncher.launch("protocolo-zero-backup.json") }, modifier = Modifier.fillMaxWidth()) { Text("EXPORTAR BACKUP") }
                        OutlinedButton(onClick = { restoreLauncher.launch(arrayOf("application/json", "text/*")) }, modifier = Modifier.fillMaxWidth()) { Text("IMPORTAR BACKUP") }
                        Text("Importar substitui os dados correspondentes do backup. Guarde o arquivo em local seguro; ele pode conter telefones pessoais.", color = Amber, fontSize = 11.sp)
                        Spacer(Modifier.height(10.dp))
                        Text("RECURSOS DE HARDWARE", color = Amber, fontWeight = FontWeight.Bold)
                        Text("Lanterna: exige flash compatível. GPS/bússola: dependem do aparelho. Chamadas: dependem de rede telefônica. Receptor FM e comunicação por rádio não são presumidos.", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("LIMITAÇÕES ATUAIS", color = Green, fontWeight = FontWeight.Bold)
                        Text("Vídeos abrem no player externo do Android. Não há mapas offline, previsão ao vivo, rádio FM, mensageria independente ou sincronização em nuvem. O jogo 2048 continua em versão simplificada por toque.", color = Muted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun NumberField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(value, onChange, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
}

@Composable
fun ResultCard(title: String, value: String, detail: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Muted, fontSize = 11.sp)
            Text(value, color = Green, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(detail, color = Muted, fontSize = 11.sp)
        }
    }
}

private fun loadList(prefs: android.content.SharedPreferences, key: String, fallback: List<String> = emptyList()): List<String> {
    val raw = prefs.getString(key, null) ?: return fallback
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { arr.getString(it) }
    } catch (_: Exception) { fallback }
}

private fun loadIntList(prefs: android.content.SharedPreferences, key: String, fallback: List<Int>): List<Int> {
    val raw = prefs.getString(key, null) ?: return fallback
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { arr.getInt(it) }.take(16).let { if (it.size == 16) it else fallback }
    } catch (_: Exception) { fallback }
}
