package br.com.protocolozero.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer

/**
 * Protocolo de primeiros socorros salvo 100% offline.
 *
 * As listas (sintomas, passos, etc.) ficam em uma única coluna TEXT separadas por [LIST_SEP]
 * para evitar TypeConverters. Use [FirstAidEntity.sintomasList] etc. para ler.
 * A coluna [busca] guarda todo o texto pesquisável, minúsculo e sem acentos.
 */
@Entity(tableName = "first_aid")
data class FirstAidEntity(
    @PrimaryKey val id: String,
    val categoria: String,
    val titulo: String,
    val nivelUrgencia: String,      // CRITICO | ALTO | MODERADO
    val tempoAcao: String,
    val sintomas: String,
    val passos: String,
    val naoFazer: String,
    val materiais: String,
    val busca: String
) {
    val sintomasList: List<String> get() = sintomas.splitList()
    val passosList: List<String> get() = passos.splitList()
    val naoFazerList: List<String> get() = naoFazer.splitList()
    val materiaisList: List<String> get() = materiais.splitList()

    private fun String.splitList(): List<String> =
        if (isBlank()) emptyList() else split(LIST_SEP)

    companion object {
        const val LIST_SEP = "\u001F" // Unit Separator: nunca aparece em texto normal
    }
}

@Dao
interface FirstAidDao {
    /** Lista completa: CRITICO primeiro, depois ALTO, depois MODERADO. */
    @Query(
        "SELECT * FROM first_aid ORDER BY " +
            "CASE nivelUrgencia WHEN 'CRITICO' THEN 0 WHEN 'ALTO' THEN 1 ELSE 2 END, titulo COLLATE NOCASE"
    )
    fun observeAll(): Flow<List<FirstAidEntity>>

    @Query("SELECT * FROM first_aid WHERE id = :id LIMIT 1")
    suspend fun byId(id: String): FirstAidEntity?

    @Query("SELECT COUNT(*) FROM first_aid")
    suspend fun count(): Int

    /**
     * Busca instantânea por UMA palavra (sintoma, título, material...). [pattern] já deve vir
     * normalizado (minúsculo, sem acentos) e com curingas, ex.: "%queimad%". Use [searchTokens]
     * para consultas com várias palavras.
     */
    @Query(
        "SELECT * FROM first_aid WHERE busca LIKE :pattern ORDER BY " +
            "CASE nivelUrgencia WHEN 'CRITICO' THEN 0 WHEN 'ALTO' THEN 1 ELSE 2 END, titulo COLLATE NOCASE"
    )
    suspend fun searchOne(pattern: String): List<FirstAidEntity>

    @Query(
        "SELECT * FROM first_aid WHERE busca LIKE :p1 AND busca LIKE :p2 AND busca LIKE :p3 ORDER BY " +
            "CASE nivelUrgencia WHEN 'CRITICO' THEN 0 WHEN 'ALTO' THEN 1 ELSE 2 END, titulo COLLATE NOCASE"
    )
    suspend fun searchThree(p1: String, p2: String, p3: String): List<FirstAidEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<FirstAidEntity>)

    @Query("DELETE FROM first_aid")
    suspend fun clear()

    /** Busca por várias palavras (todas precisam aparecer). Até 3 palavras entram no SQL. */
    @Transaction
    suspend fun searchTokens(query: String): List<FirstAidEntity> {
        val tokens = query.normalizeForSearch().split(" ").filter { it.length >= 2 }.take(3)
        return when (tokens.size) {
            0 -> emptyList()
            1 -> searchOne("%${tokens[0]}%")
            2 -> searchThree("%${tokens[0]}%", "%${tokens[1]}%", "%")
            else -> searchThree("%${tokens[0]}%", "%${tokens[1]}%", "%${tokens[2]}%")
        }
    }
}

/** minúsculo, sem acentos e sem pontuação: "Hemorragia, Torniquête!" -> "hemorragia torniquete". */
fun String.normalizeForSearch(): String =
    Normalizer.normalize(lowercase(), Normalizer.Form.NFD)
        .replace("\\p{Mn}+".toRegex(), "")
        .replace("[^a-z0-9 ]".toRegex(), " ")
        .replace("\\s+".toRegex(), " ")
        .trim()

/**
 * Popula o banco lendo assets/first_aid_library.json sem internet.
 * Roda na primeira abertura e de novo apenas quando o campo "versao" do JSON aumentar
 * (assim você atualiza os protocolos mandando um app novo, sem perder nada).
 */
object DatabaseSeeder {
    private const val ASSET = "first_aid_library.json"
    private const val PREFS = "first_aid_seed"
    private const val KEY_VERSION = "versao"
    private val lock = Mutex()

    suspend fun seedIfNeeded(context: Context, db: ZeroDatabase = ZeroDatabase.get(context)) {
        lock.withLock {
            withContext(Dispatchers.IO) {
                val app = context.applicationContext
                val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                val dao = db.firstAidDao()
                val root = JSONObject(app.assets.open(ASSET).bufferedReader(Charsets.UTF_8).use { it.readText() })
                val version = root.optInt("versao", 1)
                if (dao.count() > 0 && prefs.getInt(KEY_VERSION, 0) >= version) return@withContext

                dao.upsertAll(parse(root.getJSONArray("protocolos")))
                prefs.edit().putInt(KEY_VERSION, version).apply()
            }
        }
    }

    private fun parse(array: JSONArray): List<FirstAidEntity> =
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            val sintomas = o.strings("sintomas_identificacao")
            val passos = o.strings("passo_a_passo")
            val naoFazer = o.strings("o_que_nao_fazer")
            val materiais = o.strings("materiais_improvisados")
            val titulo = o.getString("titulo")
            val categoria = o.getString("categoria")
            FirstAidEntity(
                id = o.getString("id"),
                categoria = categoria,
                titulo = titulo,
                nivelUrgencia = o.getString("nivel_urgencia"),
                tempoAcao = o.getString("tempo_acao"),
                sintomas = sintomas.join(),
                passos = passos.join(),
                naoFazer = naoFazer.join(),
                materiais = materiais.join(),
                busca = (listOf(titulo, categoria) + sintomas + passos + materiais)
                    .joinToString(" ").normalizeForSearch()
            )
        }

    private fun JSONObject.strings(key: String): List<String> {
        val a = optJSONArray(key) ?: return emptyList()
        return (0 until a.length()).map { a.getString(it) }
    }

    private fun List<String>.join() = joinToString(FirstAidEntity.LIST_SEP)
}
