package br.com.protocolozero

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.BackHandler
import br.com.protocolozero.data.DatabaseSeeder
import br.com.protocolozero.data.FirstAidEntity
import br.com.protocolozero.data.ZeroDatabase
import kotlinx.coroutines.delay

// ---------- Paleta: 3 temas pensados para leitura sob estresse ----------

private enum class AidTheme(val label: String, val bg: Color, val panel: Color, val text: Color, val muted: Color) {
    /** OLED preto puro: economiza bateria e não ofusca à noite. */
    ECONOMIA("ECONOMIA", Color.Black, Color(0xFF111111), Color(0xFFFFFFFF), Color(0xFFBDBDBD)),
    /** Fundo escuro com texto amarelo: contraste máximo em ambiente escuro. */
    NOTURNO("NOTURNO", Color(0xFF0B0B0B), Color(0xFF1C1C1C), Color(0xFFFFEB3B), Color(0xFFE0E0E0)),
    /** Fundo branco e texto preto: contraste máximo sob sol forte. */
    DIA("DIA", Color.White, Color(0xFFEFEFEF), Color.Black, Color(0xFF333333))
}

private val Critical = Color(0xFFFF5252)
private val High = Color(0xFFFFA726)
private val Moderate = Color(0xFFFFEE58)
private val Danger = Color(0xFFFF1744)
private val Safe = Color(0xFF00E676)

private fun urgencyColor(level: String) = when (level) {
    "CRITICO" -> Critical
    "ALTO" -> High
    else -> Moderate
}

private fun urgencyLabel(level: String) = when (level) {
    "CRITICO" -> "CRÍTICO"
    "ALTO" -> "ALTO"
    else -> "MODERADO"
}

/** Ponto de entrada. Funciona sem internet: o banco é populado pelo [DatabaseSeeder]. */
@Composable
fun FirstAidScreen() {
    val context = LocalContext.current
    val db = remember { ZeroDatabase.get(context) }
    val dao = remember { db.firstAidDao() }
    var ready by remember { mutableStateOf(false) }
    var theme by remember { mutableStateOf(AidTheme.ECONOMIA) }
    var textScale by remember { mutableStateOf(1.0f) }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf<String?>(null) }
    var results by remember { mutableStateOf<List<FirstAidEntity>>(emptyList()) }

    LaunchedEffect(Unit) {
        DatabaseSeeder.seedIfNeeded(context, db)
        ready = true
    }

    // Busca instantânea: pequeno debounce só para não consultar a cada tecla em celular fraco.
    LaunchedEffect(ready, query) {
        if (!ready) return@LaunchedEffect
        if (query.isNotBlank()) delay(120)
        results = if (query.isBlank()) emptyList() else dao.searchTokens(query)
    }
    val allFlow = remember(dao) { dao.observeAll() }
    val all by allFlow.collectAsState(initial = emptyList())
    val categories = remember(all) { all.map { it.categoria }.distinct() }
    val shown = when {
        query.isNotBlank() -> results
        category != null -> all.filter { it.categoria == category }
        else -> all
    }
    val selected = selectedId?.let { id -> all.firstOrNull { it.id == id } }

    BackHandler(enabled = selected != null) { selectedId = null }

    Column(Modifier.fillMaxSize().background(theme.bg)) {
        ToolbarRow(theme, textScale, { theme = it }, { textScale = it })
        if (selected != null) {
            ProtocolDetail(selected, theme, textScale, onBack = { selectedId = null })
        } else {
            ProtocolList(
                theme = theme, scale = textScale, query = query, onQuery = { query = it },
                categories = categories, category = category, onCategory = { category = it },
                list = shown, loading = !ready, onOpen = { selectedId = it.id }
            )
        }
    }
}

// ---------- Barra superior: 192, tema e tamanho do texto ----------

@Composable
private fun ToolbarRow(theme: AidTheme, scale: Float, onTheme: (AidTheme) -> Unit, onScale: (Float) -> Unit) {
    val context = LocalContext.current
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BigButton("LIGAR 192 · SAMU", Danger, Color.White, Modifier.weight(1f)) { dial(context, "192") }
            BigButton("193 · BOMBEIROS", Danger, Color.White, Modifier.weight(1f)) { dial(context, "193") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            AidTheme.values().forEach { t ->
                val on = t == theme
                OutlinedButton(
                    onClick = { onTheme(t) },
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    contentPadding = PaddingValues(4.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (on) theme.text else Color.Transparent,
                        contentColor = if (on) theme.bg else theme.text
                    ),
                    border = BorderStroke(2.dp, theme.text)
                ) { Text(t.label, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            }
            SmallSquare("A−", theme) { onScale((scale - 0.15f).coerceAtLeast(0.85f)) }
            SmallSquare("A+", theme) { onScale((scale + 0.15f).coerceAtMost(1.6f)) }
        }
    }
}

@Composable
private fun SmallSquare(label: String, theme: AidTheme, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick, modifier = Modifier.size(48.dp), contentPadding = PaddingValues(0.dp),
        border = BorderStroke(2.dp, theme.text),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = theme.text)
    ) { Text(label, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
}

@Composable
private fun BigButton(label: String, bg: Color, fg: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.heightIn(min = 56.dp),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = bg, contentColor = fg)
    ) { Text(label, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold) }
}

/** Abre o discador já com o número; o usuário só toca em chamar (não exige permissão). */
private fun dial(context: android.content.Context, number: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) { /* aparelho sem telefonia (tablet): nada a fazer */ }
}

// ---------- Lista + busca ----------

@Composable
private fun ProtocolList(
    theme: AidTheme, scale: Float,
    query: String, onQuery: (String) -> Unit,
    categories: List<String>, category: String?, onCategory: (String?) -> Unit,
    list: List<FirstAidEntity>, loading: Boolean, onOpen: (FirstAidEntity) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        OutlinedTextField(
            value = query, onValueChange = onQuery, singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Buscar: sintoma ou situação (ex.: sangue, queimadura, não respira)", color = theme.muted) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            textStyle = LocalTextStyleLarge(theme.text, scale),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = theme.text, unfocusedBorderColor = theme.muted, cursorColor = theme.text
            )
        )
        Spacer(Modifier.height(8.dp))
        if (query.isBlank()) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { CatChip("TODOS", category == null, theme) { onCategory(null) } }
                items(categories) { c -> CatChip(c, category == c, theme) { onCategory(if (category == c) null else c) } }
            }
            Spacer(Modifier.height(8.dp))
        }
        when {
            loading -> Text("Carregando protocolos…", color = theme.text, fontSize = (18 * scale).sp)
            list.isEmpty() -> Text(
                if (query.isBlank()) "Nenhum protocolo." else "Nada encontrado. Tente outra palavra (ex.: respira, sangra, queima, convulsão).",
                color = theme.text, fontSize = (18 * scale).sp
            )
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                items(list, key = { it.id }) { p -> ProtocolCard(p, theme, scale) { onOpen(p) } }
                item { DisclaimerText(theme) }
            }
        }
    }
}

@Composable
private fun LocalTextStyleLarge(color: Color, scale: Float) =
    androidx.compose.ui.text.TextStyle(color = color, fontSize = (18 * scale).sp)

@Composable
private fun CatChip(label: String, selected: Boolean, theme: AidTheme, onClick: () -> Unit) {
    Box(
        Modifier
            .heightIn(min = 44.dp)
            .background(if (selected) theme.text else Color.Transparent, RoundedCornerShape(22.dp))
            .border(2.dp, theme.text, RoundedCornerShape(22.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) { Text(label.uppercase(), color = if (selected) theme.bg else theme.text, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun ProtocolCard(p: FirstAidEntity, theme: AidTheme, scale: Float, onClick: () -> Unit) {
    val color = urgencyColor(p.nivelUrgencia)
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 72.dp)
            .background(theme.panel, RoundedCornerShape(12.dp))
            .border(2.dp, color, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(10.dp).height(48.dp).background(color, RoundedCornerShape(5.dp)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(p.titulo, color = theme.text, fontSize = (19 * scale).sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(2.dp))
            Text("${urgencyLabel(p.nivelUrgencia)} · ${p.categoria}", color = theme.muted, fontSize = (13 * scale).sp)
        }
    }
}

@Composable
private fun DisclaimerText(theme: AidTheme) {
    Text(
        "Orientação para leigos, baseada em diretrizes AHA/Cruz Vermelha e no Guia MEC/UNIFAP. " +
            "Não substitui treinamento nem atendimento médico. Sempre que possível, ligue 192.",
        color = theme.muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 12.dp)
    )
}

// ---------- Detalhe: passo a passo ----------

@Composable
private fun ProtocolDetail(p: FirstAidEntity, theme: AidTheme, scale: Float, onBack: () -> Unit) {
    // Mantém a tela acesa enquanto o protocolo está aberto (a pessoa está com as mãos ocupadas).
    val view = LocalView.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }
    var oneAtATime by remember(p.id) { mutableStateOf(false) }
    var step by remember(p.id) { mutableStateOf(0) }
    val steps = p.passosList
    val color = urgencyColor(p.nivelUrgencia)

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BigButton("← VOLTAR", theme.text, theme.bg, Modifier.weight(1f), onBack)
            BigButton(if (oneAtATime) "VER TODOS" else "UM PASSO POR VEZ", theme.panel, theme.text, Modifier.weight(1f)) {
                oneAtATime = !oneAtATime; step = 0
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(p.titulo, color = theme.text, fontSize = (26 * scale).sp, fontWeight = FontWeight.ExtraBold)
            Row(Modifier.background(color, RoundedCornerShape(8.dp)).padding(horizontal = 12.dp, vertical = 6.dp)) {
                Text("URGÊNCIA ${urgencyLabel(p.nivelUrgencia)}", color = Color.Black, fontWeight = FontWeight.ExtraBold, fontSize = (14 * scale).sp)
            }
            Text("⏱ ${p.tempoAcao}", color = theme.text, fontSize = (17 * scale).sp, fontWeight = FontWeight.SemiBold)

            if (oneAtATime && steps.isNotEmpty()) {
                SingleStep(steps, step, theme, scale, onPrev = { if (step > 0) step-- }, onNext = { if (step < steps.lastIndex) step++ })
            } else {
                Section("COMO RECONHECER", theme.text, theme) {
                    p.sintomasList.forEach { Bullet(it, theme, scale) }
                }
                Section("FAÇA AGORA", Safe, theme) {
                    steps.forEach { StepRow(it, theme, scale) }
                }
            }

            Section("NUNCA FAÇA", Danger, theme) {
                p.naoFazerList.forEach { Bullet(it, theme, scale, "✖ ") }
            }
            if (p.materiaisList.isNotEmpty()) {
                Section("O QUE USAR NO LUGAR", theme.text, theme) {
                    p.materiaisList.forEach { Bullet(it, theme, scale) }
                }
            }
            DisclaimerText(theme)
        }
    }
}

@Composable
private fun SingleStep(steps: List<String>, index: Int, theme: AidTheme, scale: Float, onPrev: () -> Unit, onNext: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(theme.panel, RoundedCornerShape(16.dp)).border(3.dp, Safe, RoundedCornerShape(16.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("PASSO ${index + 1} DE ${steps.size}", color = Safe, fontWeight = FontWeight.ExtraBold, fontSize = (16 * scale).sp)
        // Remove a numeração "3. " do texto para não duplicar o contador acima.
        Text(steps[index].replace(Regex("^\\d+\\.\\s*"), ""), color = theme.text, fontSize = (28 * scale).sp, fontWeight = FontWeight.Bold, lineHeight = (36 * scale).sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BigButton("◀ ANTERIOR", theme.panel, theme.text, Modifier.weight(1f).heightIn(min = 72.dp), onPrev)
            BigButton(if (index == steps.lastIndex) "FIM" else "PRÓXIMO ▶", Safe, Color.Black, Modifier.weight(1f).heightIn(min = 72.dp), onNext)
        }
    }
}

@Composable
private fun Section(title: String, accent: Color, theme: AidTheme, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(theme.panel, RoundedCornerShape(14.dp)).border(2.dp, accent, RoundedCornerShape(14.dp)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(title, color = accent, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, letterSpacing = 1.sp)
        content()
    }
}

@Composable
private fun StepRow(text: String, theme: AidTheme, scale: Float) {
    // O JSON já traz "1. ..." no início; destacamos o número e deixamos o resto grande.
    val match = Regex("^(\\d+)\\.\\s*(.*)$", RegexOption.DOT_MATCHES_ALL).find(text)
    val number = match?.groupValues?.get(1) ?: "•"
    val body = match?.groupValues?.get(2) ?: text
    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.size((40 * scale).dp).background(Safe, RoundedCornerShape(20.dp)), contentAlignment = Alignment.Center) {
            Text(number, color = Color.Black, fontWeight = FontWeight.ExtraBold, fontSize = (18 * scale).sp)
        }
        Text(body, color = theme.text, fontSize = (20 * scale).sp, lineHeight = (27 * scale).sp, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun Bullet(text: String, theme: AidTheme, scale: Float, mark: String = "• ") {
    Text("$mark$text", color = theme.text, fontSize = (18 * scale).sp, lineHeight = (25 * scale).sp)
}
