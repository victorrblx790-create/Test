package br.com.protocolozero.data

import android.content.Context
import androidx.room.Dao
import androidx.room.ColumnInfo
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction

@Entity(tableName = "inventory")
data class InventoryRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val description: String
)

@Entity(tableName = "checklist")
data class ChecklistRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val description: String,
    val completed: Boolean = false,
    val position: Int = 0
)

@Dao
interface ZeroDao {
    @Query("SELECT * FROM inventory ORDER BY id DESC")
    suspend fun getInventory(): List<InventoryRecord>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addInventory(item: InventoryRecord)

    @Query("DELETE FROM inventory WHERE id = :id")
    suspend fun deleteInventory(id: Long)

    @Query("DELETE FROM inventory")
    suspend fun clearInventory()

    @Insert
    suspend fun insertInventory(items: List<InventoryRecord>)

    @Query("SELECT * FROM checklist ORDER BY position ASC, id ASC")
    suspend fun getChecklist(): List<ChecklistRecord>

    @Query("DELETE FROM checklist")
    suspend fun clearChecklist()

    @Insert
    suspend fun insertChecklist(items: List<ChecklistRecord>)

    @Transaction
    suspend fun replaceInventory(items: List<InventoryRecord>) {
        clearInventory()
        if (items.isNotEmpty()) insertInventory(items)
    }

    @Transaction
    suspend fun replaceChecklist(items: List<ChecklistRecord>) {
        clearChecklist()
        if (items.isNotEmpty()) insertChecklist(items)
    }
}

@Database(
    entities = [InventoryRecord::class, ChecklistRecord::class, OfflineMedia::class, FirstAidEntity::class],
    version = 6,
    exportSchema = true
)
abstract class ZeroDatabase : RoomDatabase() {
    abstract fun dao(): ZeroDao
    abstract fun mediaDao(): OfflineMediaDao
    abstract fun firstAidDao(): FirstAidDao

    companion object {
        private val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
            override fun migrate(database: androidx.sqlite.db.SupportSQLiteDatabase) {
                database.execSQL(
                    "CREATE TABLE IF NOT EXISTS offline_media (uri TEXT NOT NULL, title TEXT NOT NULL, category TEXT NOT NULL, durationMs INTEGER NOT NULL, lastPositionMs INTEGER NOT NULL, isFavorite INTEGER NOT NULL, addedAt INTEGER NOT NULL, PRIMARY KEY(uri))"
                )
            }
        }
        private val MIGRATION_2_3 = object : androidx.room.migration.Migration(2, 3) {
            override fun migrate(database: androidx.sqlite.db.SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE offline_media ADD COLUMN description TEXT NOT NULL DEFAULT ''")
                database.execSQL("ALTER TABLE offline_media ADD COLUMN releaseYear INTEGER")
                database.execSQL("ALTER TABLE offline_media ADD COLUMN genre TEXT NOT NULL DEFAULT ''")
                database.execSQL("ALTER TABLE offline_media ADD COLUMN lastPlayedAt INTEGER NOT NULL DEFAULT 0")
            }
        }
        private val MIGRATION_3_4 = object : androidx.room.migration.Migration(3, 4) {
            override fun migrate(database: androidx.sqlite.db.SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE offline_media ADD COLUMN seriesTitle TEXT NOT NULL DEFAULT ''")
                database.execSQL("ALTER TABLE offline_media ADD COLUMN seasonNumber INTEGER")
                database.execSQL("ALTER TABLE offline_media ADD COLUMN episodeNumber INTEGER")
            }
        }
        private val MIGRATION_4_5 = object : androidx.room.migration.Migration(4, 5) {
            override fun migrate(database: androidx.sqlite.db.SupportSQLiteDatabase) {
                // Suporte ao catálogo de domínio público (Internet Archive) na aba Cinema.
                database.execSQL("ALTER TABLE offline_media ADD COLUMN coverUrl TEXT NOT NULL DEFAULT ''")
                database.execSQL("ALTER TABLE offline_media ADD COLUMN remoteUrl TEXT NOT NULL DEFAULT ''")
                database.execSQL("ALTER TABLE offline_media ADD COLUMN sourceIdentifier TEXT NOT NULL DEFAULT ''")
                database.execSQL("ALTER TABLE offline_media ADD COLUMN downloadedPath TEXT")
                database.execSQL("ALTER TABLE offline_media ADD COLUMN downloadId INTEGER")
                database.execSQL("ALTER TABLE offline_media ADD COLUMN isCatalogItem INTEGER NOT NULL DEFAULT 0")
            }
        }
        private val MIGRATION_5_6 = object : androidx.room.migration.Migration(5, 6) {
            override fun migrate(database: androidx.sqlite.db.SupportSQLiteDatabase) {
                // Biblioteca de primeiros socorros offline (populada pelo DatabaseSeeder).
                database.execSQL(
                    "CREATE TABLE IF NOT EXISTS first_aid (id TEXT NOT NULL, categoria TEXT NOT NULL, titulo TEXT NOT NULL, nivelUrgencia TEXT NOT NULL, tempoAcao TEXT NOT NULL, sintomas TEXT NOT NULL, passos TEXT NOT NULL, naoFazer TEXT NOT NULL, materiais TEXT NOT NULL, busca TEXT NOT NULL, PRIMARY KEY(id))"
                )
            }
        }
        @Volatile private var INSTANCE: ZeroDatabase? = null

        fun get(context: Context): ZeroDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    ZeroDatabase::class.java,
                    "protocolo_zero.db"
                ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6).build().also { INSTANCE = it }
            }
    }
}


@Entity(tableName = "offline_media")
data class OfflineMedia(
    @PrimaryKey val uri: String,
    val title: String,
    val category: String = "Vídeos",
    val durationMs: Long = 0L,
    val lastPositionMs: Long = 0L,
    val isFavorite: Boolean = false,
    val addedAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "''") val description: String = "",
    val releaseYear: Int? = null,
    @ColumnInfo(defaultValue = "''") val genre: String = "",
    @ColumnInfo(defaultValue = "0") val lastPlayedAt: Long = 0L,
    @ColumnInfo(defaultValue = "''") val seriesTitle: String = "",
    val seasonNumber: Int? = null,
    val episodeNumber: Int? = null,
    // --- Catálogo de domínio público (Internet Archive) ---
    /** URL da miniatura/capa (ex.: https://archive.org/services/img/{identifier}). */
    @ColumnInfo(defaultValue = "''") val coverUrl: String = "",
    /** URL de streaming original do item (ex.: .../download/{identifier}/{identifier}.mp4). */
    @ColumnInfo(defaultValue = "''") val remoteUrl: String = "",
    /** Identificador do item no Internet Archive (vazio para importações locais). */
    @ColumnInfo(defaultValue = "''") val sourceIdentifier: String = "",
    /** Caminho/URI local do arquivo já baixado pelo DownloadManager; null = ainda não baixado. */
    val downloadedPath: String? = null,
    /** ID retornado pelo DownloadManager enquanto um download está em andamento. */
    val downloadId: Long? = null,
    /** true = item veio do catálogo remoto; false = importado manualmente pelo usuário. */
    @ColumnInfo(defaultValue = "0") val isCatalogItem: Boolean = false
)

@Dao
interface OfflineMediaDao {
    @Query("SELECT * FROM offline_media ORDER BY addedAt DESC")
    suspend fun all(): List<OfflineMedia>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(item: OfflineMedia)

    @Query("DELETE FROM offline_media WHERE uri = :uri")
    suspend fun delete(uri: String)

    @Query("UPDATE offline_media SET lastPositionMs = :position, lastPlayedAt = :playedAt WHERE uri = :uri")
    suspend fun savePosition(uri: String, position: Long, playedAt: Long)

    @Query("UPDATE offline_media SET title = :title, description = :description, releaseYear = :year, genre = :genre, category = :category, seriesTitle = :seriesTitle, seasonNumber = :season, episodeNumber = :episode WHERE uri = :uri")
    suspend fun updateMetadata(uri: String, title: String, description: String, year: Int?, genre: String, category: String, seriesTitle: String, season: Int?, episode: Int?)

    @Query("UPDATE offline_media SET isFavorite = :favorite WHERE uri = :uri")
    suspend fun setFavorite(uri: String, favorite: Boolean)

    @Query("UPDATE offline_media SET category = :category WHERE uri = :uri")
    suspend fun setCategory(uri: String, category: String)

    // --- Catálogo de domínio público (Internet Archive) ---

    @Query("SELECT * FROM offline_media WHERE isCatalogItem = 1 ORDER BY releaseYear DESC, title ASC")
    suspend fun catalogAll(): List<OfflineMedia>

    @Query("SELECT * FROM offline_media WHERE uri = :uri LIMIT 1")
    suspend fun findByUri(uri: String): OfflineMedia?

    @Query("SELECT * FROM offline_media WHERE downloadId = :id LIMIT 1")
    suspend fun findByDownloadId(id: Long): OfflineMedia?

    @Query("UPDATE offline_media SET title = :title, description = :description, releaseYear = :year, coverUrl = :coverUrl, remoteUrl = :remoteUrl WHERE uri = :uri")
    suspend fun updateCatalogMetadata(uri: String, title: String, description: String, year: Int?, coverUrl: String, remoteUrl: String)

    @Query("UPDATE offline_media SET downloadId = :id WHERE uri = :uri")
    suspend fun setDownload(uri: String, id: Long)

    @Query("UPDATE offline_media SET downloadedPath = :path, downloadId = NULL WHERE uri = :uri")
    suspend fun markDownloaded(uri: String, path: String)

    @Query("UPDATE offline_media SET downloadedPath = NULL, downloadId = NULL WHERE uri = :uri")
    suspend fun clearDownload(uri: String)
}
