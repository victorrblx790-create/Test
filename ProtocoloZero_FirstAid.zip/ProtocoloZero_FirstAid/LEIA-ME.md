# Módulo Primeiros Socorros — ProtocoloZero

Copie as pastas para dentro do projeto (mesmos caminhos, substituindo ZeroDatabase.kt e MainActivity.kt):

- app/src/main/assets/first_aid_library.json  (28 protocolos, versao 1)
- app/src/main/java/br/com/protocolozero/data/FirstAid.kt  (FirstAidEntity, FirstAidDao, DatabaseSeeder)
- app/src/main/java/br/com/protocolozero/data/ZeroDatabase.kt  (version 5 -> 6, MIGRATION_5_6, firstAidDao())
- app/src/main/java/br/com/protocolozero/FirstAidScreen.kt  (UI)
- app/src/main/java/br/com/protocolozero/MainActivity.kt  (nova aba "PRIMEIROS SOCORROS" + atalho)

Sem novas dependências. Para atualizar protocolos: edite o JSON e aumente "versao".
